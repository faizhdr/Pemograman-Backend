<h3>Data Mahasiswa</h3>
<ol>
<li>Mahasiswa 1: {{ $mhs1 }}, Asal: {{ $asal1 }} </li>
<li>Mahasiswa 2: {{ $mhs2 }}, Asal: {{ $asal2 }}</li>
</ol>